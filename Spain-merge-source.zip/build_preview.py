from pathlib import Path
import json, html, shutil
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'docs'
d=json.loads((OUT/'data.json').read_text())
e=lambda v:html.escape(str(v),quote=True)
cards=[]
approved_cards=[]
pipeline_cards=[]
for s in d['scenes']:
    approved=s.get('approval_state')=='approved' and all(s.get('gates',{}).get(k)=='pass' for k in ['visual','technical','provenance','commercial_ip','publication'])
    (OUT/'manifests'/f"{s['entry_id']}.json").write_text(json.dumps(s,ensure_ascii=False,indent=2))
    editions=''.join(f'<a href="{e(x["file"])}" download>{e(x["label"])}</a>' for x in s['editions'])
    cards.append(f'''<article class="card" id="{e(s['entry_id'])}" data-search="{e(s['city']+' '+s['caption']+' '+s['region'])}">
<p class="review-label">{"APPROVED SCENE" if approved else "CANDIDATE · AWAITING QC · NOT APPROVED"}</p><p class="place">Spain / {e(s['region'])} / {e(s['city'])}</p>
<button class="image-button" data-id="{e(s['entry_id'])}" data-format="16x9" aria-label="View {e(s['caption'])} full screen"><img src="{e(s['file_16x9'])}" alt="{e(s['alt_text'])}" width="1920" height="1080" loading="lazy"><span>VIEW IMAGE</span></button>
<div class="meta"><span class="entry-id">{e(s['entry_id'])}</span><a class="badge" href="#license">Free · no credit needed</a></div>
<h3>{e(s['caption'])}</h3><p>{e(s['composition'])}</p><p>{e(s['description'])}</p>
<p class="scenario">Scenario: {e(s['scenario_label'])}</p><p class="status">{e(s['status'])}</p>
<button class="portrait" data-id="{e(s['entry_id'])}" data-format="4x5">View 4:5 portrait</button>
<div class="downloads"><a class="download" href="{e(s['file_16x9'])}" download>Download 16:9<small>1920 × 1080</small></a><a class="download" href="{e(s['file_4x5'])}" download>Download 4:5<small>864 × 1080</small></a></div>
<details class="details"><summary>Viewpoint, conditions &amp; editions</summary><p>{e(s['viewpoint'])}</p><p>{e(s['weather'])}</p><p>{e(s['limitations'])}</p><p>The current downloads use the new gradient typography. Original editions are preserved below. Creator permission is separate from third-party rights clearance.</p><div class="editions">{editions}</div></details></article>''')
    (approved_cards if approved else pipeline_cards).append(cards[-1])
groups={}
for s in d['scenes']:groups.setdefault(s['region'],{}).setdefault(s['city'],[]).append(s)
directory=''
for region,cities in groups.items():
    directory+=f'<div class="region-index"><strong>{e(region)}</strong>'
    for city,scenes in cities.items():
        directory+=f'<button data-filter="{e(city)}">{e(city)} · {len(scenes)}</button>'
        directory+=''.join(f'<a class="scene-link" href="#{e(s["entry_id"])}">{e(s["caption"])}</a>' for s in scenes)
    directory+='</div>'
queue=''.join(f'<li class="queued-item" data-search="{e(s.get("city","")+" "+s["caption"]+" "+s["region"])}"><span class="entry-id">{e(s["entry_id"])}</span><h3>{e(s["caption"])}</h3><p>{e(s["region"])}</p><p>{e(s["composition"])}</p><span class="queue-state">{e(s["status"])}</span></li>' for s in d['starters'])
regions=''.join(f'<details><summary>{e(region)}</summary><ul>'+''.join(f'<li>{e(a)}</li>' for a in anchors)+'</ul><p class="queue-state">Coverage planned · not a completed inventory</p></details>' for region,anchors in d['coverage'].items())
template='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Jason D’s Vision — Spain</title><meta name="description" content="Spain-only preview of Jason D’s Vision. AI-generated artistic location imagery, free to use with no credit required."><link rel="stylesheet" href="style.css"><script src="app.js" defer></script></head><body>
<header><a class="brand" href="#">Jason D’s Vision <span>SPAIN</span></a><nav aria-label="Main"><a href="#library">Gallery</a><a href="#pipeline">Pipeline</a><a href="#coverage">Regions</a><a href="#license">License</a></nav></header><main>
<p class="pointer">Every image is free to use — no credit required. <a href="#license">See license below.</a></p>
<section class="intro"><p class="eyebrow">THE SPAIN COLLECTION · PUBLIC PREVIEW</p><h1>A place. A moment.<br><em>Spain, interpreted.</em></h1><p>AI-generated artistic interpretations of real places. Each scene carries its location, scenario time and review status.</p><p class="note">Only approved scenes enter the gallery. Candidates and queued work are kept in the separate pipeline. Internal approval is not legal certification.</p></section>
<section id="library"><div class="section-heading"><h2>Approved gallery</h2><p>@@APPROVED@@ approved scenes</p></div><div id="approved-cards">@@APPROVEDCARDS@@</div>@@EMPTY@@</section>
<section id="pipeline" class="pipeline"><p class="eyebrow">WORK IN PROGRESS · NOT THE APPROVED GALLERY</p><h2>Production pipeline</h2><p>These candidates await QC. Queued scenes are plans only; no image is implied. Candidate downloads are review editions.</p><label for="search">Search Spain by city, site or region</label><div class="search-row"><input id="search" type="search" placeholder="City, site or region" autocomplete="off"><button id="clear" type="button">Clear</button></div><p id="result-count" role="status" aria-live="polite"></p><div class="layout"><aside><h3>Candidate index</h3><p class="country">Spain</p>@@INDEX@@</aside><div id="cards"><h3>Awaiting QC</h3>@@PIPELINECARDS@@</div></div><div id="no-results" hidden><h3>No scenes found</h3><p>Try another city, site or region.</p><button id="reset" type="button">Reset search</button></div>
<section id="sequence"><p class="eyebrow">THE NEXT CHAPTER</p><h2>Spain starter sequence</h2><p>The following 16 scenes are queued in Jason’s prescribed order. These entries are plans, not completed images.</p><ol id="queue">@@QUEUE@@</ol></section>
<section id="coverage"><h2>Every region. Every island.</h2><p>After the starter sequence: systematic coverage of all 17 autonomous communities, Ceuta and Melilla. Anchor lists are a starting point for research, not a claim of complete coverage. Each region’s anchors will be completed before moving to the next.</p><div id="regions">@@REGIONS@@</div></section></section>
<section class="promise"><p class="eyebrow">MADE FOR YOUR WORK</p><h2>Our promise to creators</h2><p>Beautiful, realistic imagery should never stand between a creator and their work. Everything in this gallery is free to use — for any purpose, forever, with no credit required. We make these images so the people doing the work always have something stunning to build on.</p><a href="#license">Read the full license</a></section>
<section id="license"><h2>Free to use</h2><p>Every image in Jason D's Vision is free to use for any purpose — personal or commercial. No credit is required. If you'd like to credit, 'Jason D's Vision' is appreciated, but it's entirely your choice.</p><p>Jason D's Vision waives its own rights in these images. This doesn't waive anyone else's rights: if an image happens to include a trademark, logo, or other third-party material, those rights still belong to their owners. All images are AI-generated artistic interpretations, not photographs, and use of an image doesn't imply endorsement by Jason D's Vision.</p></section>
</main><footer><p>AI-generated artistic interpretations</p><span>Jason D’s Vision</span><a href="#">Back to top</a></footer>
<dialog id="viewer" aria-labelledby="viewer-title"><div class="viewer-top"><h2 id="viewer-title"></h2><button id="close-viewer" type="button" aria-label="Close image viewer">Close ×</button></div><div class="viewer-controls"><button id="view-wide" type="button">16:9 landscape</button><button id="view-tall" type="button">4:5 portrait</button><a id="view-download" download>Download image</a></div><img id="viewer-image" alt=""><p id="viewer-caption"></p></dialog>
<script type="application/json" id="scene-data">@@DATA@@</script><noscript><p>Images and download links work without JavaScript. Enable JavaScript for search and the full-screen viewer.</p></noscript></body></html>'''
for k,v in {'APPROVED':str(len(approved_cards)),'APPROVEDCARDS':''.join(approved_cards),'PIPELINECARDS':''.join(pipeline_cards),'EMPTY':'<p class="empty-gallery">No approved Spain scenes yet. The work awaiting review is listed below.</p>' if not approved_cards else '', 'COUNT':str(len(d['scenes'])),'MASTERS':str(len(d['scenes'])*2),'INDEX':directory,'CARDS':''.join(cards),'QUEUE':queue,'REGIONS':regions,'DATA':json.dumps(d['scenes'],ensure_ascii=False).replace('</','<\\/')}.items():template=template.replace('@@'+k+'@@',v)
template=template.replace('The following 16 scenes are queued in Jason’s prescribed order.',f'The following {len(d["starters"])} remaining scenes are queued in Jason’s prescribed order.')
(OUT/'index.html').write_text(template)
(OUT/'.nojekyll').touch()
print(f"Built Spain preview: {len(d['scenes'])} candidate scenes, {len(d['starters'])} queued scenes, {len(d['coverage'])} regional directories")
