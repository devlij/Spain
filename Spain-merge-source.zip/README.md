# Jason D’s Vision — Spain preview

Spain only. GitHub Pages source: main branch, /docs directory. No repository or deployment has yet been verified.

Run `python3 build_preview.py` after editing docs/data.json. Only approval_state=approved AND all five gates explicitly pass can enter the approved gallery. Everything else is visibly separate in the pipeline. Queued records never count as produced images. Preserve original editions.

Publish this repository to GitHub, enable Pages from main /docs, and verify the resulting public URL before reporting success. Future approved scenes update this same repository. Do not deploy to Sites, Muse or Netlify.

Public content only: no private evidence cards. Existing Córdoba pairs are historical candidates, not retrospectively approved under the current kit.
